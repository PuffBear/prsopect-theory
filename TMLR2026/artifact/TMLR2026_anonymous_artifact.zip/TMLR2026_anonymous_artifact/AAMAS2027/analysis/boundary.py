"""Grouped binomial Firth logit; vectorized independent fits with step halving.
Jeffreys penalty is 0.5 log|X'WX|. Seed multiplicities are frequency weights.
See https://github.com/ikosmidis/brglm2 for the adjusted-score formulation.
"""
import numpy as np
from scipy.special import expit

def firth(w, k, n, maxiter=400, tol=1e-7):
    w=np.asarray(w,float); k=np.atleast_2d(k).astype(float); n=np.broadcast_to(n,k.shape).astype(float)
    center=w.mean(); scale=w.std(); z=(w-center)/scale
    beta=np.zeros((len(k),2)); active=np.ones(len(k),bool); converged=np.zeros(len(k),bool)
    def state(b):
        eta=b[:,0,None]+b[:,1,None]*z; p=expit(eta); v=n*p*(1-p)
        a=v.sum(1); c=(v*z).sum(1); d=(v*z*z).sum(1); det=a*d-c*c
        safe=np.maximum(det,1e-300)
        h=v*(d[:,None]-2*c[:,None]*z+a[:,None]*z*z)/safe[:,None]
        residual=k-n*p+h*(.5-p)
        score=np.column_stack((residual.sum(1),(residual*z).sum(1)))
        obj=(k*eta-n*np.logaddexp(0,eta)).sum(1)+.5*np.log(safe)
        return obj,score,a,c,d,det
    for iteration in range(maxiter):
        obj,u,a,c,d,det=state(beta)
        good=np.isfinite(obj)&(det>1e-16)
        done=good&(np.max(np.abs(u),axis=1)<tol)
        converged|=done; active&=good&~done
        if not active.any():break
        step=np.column_stack((d*u[:,0]-c*u[:,1],a*u[:,1]-c*u[:,0]))/np.maximum(det,1e-300)[:,None]
        step[~active]=0
        # Limit large scoring steps, then enforce ascent in penalized likelihood.
        step/=np.maximum(1,np.max(np.abs(step),axis=1)/5)[:,None]
        trial=beta+step
        for _ in range(30):
            val=state(trial)[0]; bad=active&((val<obj-1e-12)|~np.isfinite(val))
            if not bad.any():break
            step[bad]*=.5;trial[bad]=beta[bad]+step[bad]
        beta[active]=trial[active]
    final=state(beta); converged|=(np.max(np.abs(final[1]),axis=1)<tol)
    slope=beta[:,1]/scale; intercept=beta[:,0]-slope*center
    wc=np.divide(-intercept,slope,out=np.full(len(k),np.nan),where=np.abs(slope)>1e-9)
    degenerate=(k.sum(1)==0)|(k.sum(1)==n.sum(1))
    status=np.where(~converged,'nonconverged',np.where(degenerate,'single_outcome',np.where(np.abs(slope)<=1e-9,'flat','ok')))
    wc[status!='ok']=np.nan
    return dict(b0=intercept,b1=slope,wcrit=wc,converged=converged,status=status,
                in_grid=np.isfinite(wc)&(wc>=w.min())&(wc<=w.max()),iterations=iteration+1)

def wilson(k,n):
    p=np.asarray(k)/n; z=1.959963984540054; den=1+z*z/n
    mid=(p+z*z/(2*n))/den; delta=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return mid-delta,mid+delta

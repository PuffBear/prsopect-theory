from pathlib import Path
import json,hashlib
import numpy as np,pandas as pd
P=Path(__file__).resolve().parents[1]/'generated';ROOT=P.parents[1]
read=lambda f:pd.read_csv(P/f,keep_default_na=False)
d=read('canonical_runs.csv');f=read('boundary_estimates.csv');c=read('collapse_cells.csv');b=read('bootstrap_draws.csv');v=read('endpoint_differences.csv')
assert len(d)==5739
assert not d.duplicated(['configuration','condition','w','seed']).any()
assert len(d[d.setting=='lbf_mappo'])==1599
assert len(d[(d.setting=='supply_ppo')&(d.condition=='lambda7')])==140
assert len(d[(d.setting=='supply_ppo')&(d.condition=='lambda6')])==140
assert len(d[(d.setting=='supply_ppo')&(d.condition=='lambda5')])==140
assert len(read('missing_cells.csv'))==1 and len(read('excluded_rows.csv'))==1
assert (f.bootstrap_usable==2000).all() and (f.bootstrap_nonconverged==0).all()
assert len(b)==len(f)*2000 and (b.status=='ok').all()
assert (c.k<=c.n).all() and (c.ci_low<=c.proportion).all() and (c.ci_high>=c.proportion).all()
for r in f.itertuples():
 g=c[(c.setting==r.setting)&(c.condition==r.condition)&(c.budget==r.budget)];assert g.n.sum()==r.n
 z=b[(b.setting==r.setting)&(b.condition==r.condition)&(b.budget==r.budget)].wcrit
 assert np.allclose(np.percentile(z,[2.5,97.5]),[r.ci_low,r.ci_high])
for rel,h in json.loads((P/'input_hashes.json').read_text()).items():assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==h
assert f[(f.setting=='lbf_mappo')&(f.condition=='lambda7')].wcrit.iloc[0]>1
assert v[(v.setting=='supply_mappo')&(v.pairing=='paired')].ci_low.iloc[0]>0
print(f'PASS: {len(d)} canonical rows, {len(f)} boundary fits, {len(b)} retained bootstrap fits; counts, cells, intervals, sources and extrapolation checks.')

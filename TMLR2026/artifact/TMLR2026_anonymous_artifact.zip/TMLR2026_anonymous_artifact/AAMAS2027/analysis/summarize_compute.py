from pathlib import Path
import json,pandas as pd,numpy as np
root=Path(__file__).resolve().parents[1];out=root/'generated/pointers26_35';d=json.loads((out/'compute_log_audit.json').read_text())
def seconds(s):
 h,m,v=map(int,s.split(':'));return h*3600+m*60+v
rows=[]
for r in d['accounting']:
 f=r['fields']
 if not f:continue
 rows.append(dict(job=r['job'],name=f['Job_Name'],state=f['job_state'],cpu_seconds=seconds(f['resources_used.cput']),wall_seconds=seconds(f['resources_used.walltime']),allocated_cpus=int(f['resources_used.ncpus']),reported_memory_kb=int(f['resources_used.mem'].removesuffix('kb')),final=f['job_state']=='F'))
pd.DataFrame(rows).to_csv(out/'measured_compute.csv',index=False)
C=pd.read_csv(root/'generated/canonical_runs.csv',keep_default_na=False);rows=[]
for setting,g in C.groupby('setting'):
 for (condition,budget),h in g.groupby(['condition','budget']):
  lanes={'supply_ppo':5,'supply_mappo':5,'supply_horizon':5,'mpe_mappo':3,'lbf_mappo':2}[setting]
  numeric=pd.to_numeric(pd.Series([budget]),errors='coerce').iloc[0]
  rows.append(dict(setting=setting,condition=condition,budget=budget,observed_runs=len(h),joint_ticks_requested=numeric/lanes if np.isfinite(numeric) else None,lanes=lanes,actual_cpu_hours=None,historical_peak_memory=None,note='nominal counters only; historical achieved resource records unavailable'))
pd.DataFrame(rows).to_csv(out/'compute_inventory.csv',index=False)
print('Recorded measured PBS resources separately from nominal historical run counts')

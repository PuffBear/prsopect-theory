"""Read completed 300k untreated pilot training windows; never use evaluation signs."""
import argparse,gzip,json
from pathlib import Path
WS=[0.,.4,.5,.6,.7,.85,1.]
def analyze(root):
 root=Path(root);cells={};missing=[];folders={}
 for i,w in enumerate(WS):
  for seed in range(100,105):
   folder=root/f'run_{i*15+5+seed-100:03d}';p=folder/'evaluation_300000.json'
   if not p.exists():missing.append([w,seed]);continue
   cfg=json.loads((folder/'protocol.json').read_text())
   assert cfg['condition']=='curvature' and cfg['w']==w and cfg['seed']==seed and cfg['version']=='explicit-demand-v2'
   cells[w,seed]=json.loads(p.read_text())['summary']['collapsed'];folders[w,seed]=folder
 if missing:return {'status':'incomplete untreated pilot300k cells','missing':missing}
 props={w:sum(cells[w,s] for s in range(100,105))/5 for w in WS}
 brackets=[(a,b) for a,b in zip(WS[:-1],WS[1:]) if min(props[a],props[b])<=.5<=max(props[a],props[b])]
 if not brackets:return {'status':'unassessed: untreated pilot crossing unbracketed','proportions':props}
 selected=sorted({w for pair in brackets for w in pair});totals={};percell=[]
 for w in selected:
  for seed in range(100,105):
   sums={};steps=[]
   with gzip.open(folders[w,seed]/'diagnostics/rollouts.jsonl.gz','rt') as f:
    for line in f:
     r=json.loads(line);t=r['actual_transitions']
     if t>300160:break
     steps.append(t)
     for g in r['groups']:
      m=g['rewards']['centered'];n=m['count'];acc=sums.setdefault(g['agent'],dict(count=0,positive=0.,negative=0.,zero=0.))
      acc['count']+=n
      for k in ['positive','negative','zero']:acc[k]+=n*m[k]
   assert steps==list(range(640,300161,640)),f'Incomplete diagnostic window: {w},{seed}'
   for agent,acc in sums.items():
    percell.append(dict(w=w,seed=seed,agent=agent,**{k:(v if k=='count' else v/acc['count']) for k,v in acc.items()}))
    total=totals.setdefault(agent,dict(count=0,positive=0.,negative=0.,zero=0.))
    for k,v in acc.items():total[k]+=v
 fractions={a:{k:(v if k=='count' else v/x['count']) for k,v in x.items()} for a,x in totals.items()}
 pooled=fractions['pooled'];passed=pooled['positive']>=.1 and pooled['negative']>=.1
 return dict(status='pass' if passed else 'fail; separate mixed-sign reference pilot required',reference=0.,training_window=[640,300160],brackets=brackets,selected_w=selected,proportions=props,pooled_and_per_agent=fractions,per_cell_seed_agent=percell,interpretation='Pilot sign-coverage gate only; no gain/loss asymmetry effect inferred')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True);a=p.parse_args();r=analyze(a.root);Path(a.out).write_text(json.dumps(r,indent=2));print(r['status'])

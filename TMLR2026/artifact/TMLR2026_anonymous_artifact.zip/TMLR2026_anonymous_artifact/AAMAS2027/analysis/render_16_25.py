from pathlib import Path
import os,json
os.environ.setdefault('MPLCONFIGDIR','/private/tmp/aamas-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd,numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'generated/pointers16_25'
R=lambda n:pd.read_csv(OUT/n,keep_default_na=False)
def table(name,caption,label,head,rows,spec,wide=True):
 env='table*' if wide else 'table';text=f'\\begin{{{env}}}[t]\n\\caption{{{caption}}}\n\\label{{{label}}}\n\\centering\\small\n\\begin{{tabular}}{{{spec}}}\n\\toprule\n'+head+r' \\'+'\n\\midrule\n'+'\n'.join(x+r' \\' for x in rows)+'\n\\bottomrule\n\\end{tabular}\n'+f'\\end{{{env}}}\n';(OUT/(name+'.tex')).write_text(text)
b=R('label_sensitivity_boundaries.csv');d=R('label_sensitivity_differences.csv');rows=[]
for r in d.itertuples():
 a=b[(b.setting==r.setting)&(b.threshold==r.threshold)&(b.condition=='lambda1')].iloc[0];z=b[(b.setting==r.setting)&(b.threshold==r.threshold)&(b.condition==r.endpoint)].iloc[0]
 fmt=lambda t:f'{t.wcrit:.3f} [{t.ci_low:.3f},{t.ci_high:.3f}]'
 rows.append(f'{"MPE*" if r.setting=="mpe_mappo" else "LBF"} & {r.threshold:.4f} & {fmt(a)} & {fmt(z)} & {r.difference:+.3f} [{r.ci_low:+.3f},{r.ci_high:+.3f}] & {r.usable}')
table('label_sensitivity','Retrospective threshold sensitivity: same saved policies and Firth estimator, 2,000 paired seed-block draws. Endpoints are lambda 7 for MPE and lambda 4 for LBF. All point crossings are inside their sampled grids; full per-fit bracketing/failure/out-of-grid-bootstrap diagnostics are exported. MPE* remains provisional because historical configurations are unresolved.','tab:label_sensitivity',r'Setting & Threshold & $\lambda=1$ midpoint [CI] & Endpoint midpoint [CI] & Difference [CI] & Usable',rows,'@{}lrllll@{}')
# Independent reference policies may finish after the first render; include only completed records.
refs=[]
path=ROOT/'new_runs/references_v1/references.jsonl'
if path.exists():
 for line in path.read_text().splitlines():
  if line.strip():refs.append(json.loads(line))
refrows=[]
for r in refs:
 for metric,value in r['metrics'].items():
  if isinstance(value,(float,int)) and metric!='collapsed':refrows.append(dict(setting=r['setting'],policy=r['policy'],seed=r['seed'],metric=metric,value=value))
refdf=pd.DataFrame(refrows);refdf.to_csv(OUT/'reference_performance.csv',index=False)
P=R('performance_cells.csv');plt.rcParams.update({'font.size':8,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
fig,axes=plt.subplots(3,3,figsize=(7.1,7.4),layout='constrained')
specs=[('supply_ppo','profit'),('supply_ppo','lost_sales'),('supply_ppo','mean_S'),('supply_mappo','profit'),('supply_structural_ppo','mean_order'),('mpe_mappo','mean_reward'),('mpe_mappo','mean_occupancy'),('lbf_mappo','mean_reward')]
labels={'profit':'Five-node episode profit','lost_sales':'Lost-sales ratio','mean_S':'Reset base-stock action','mean_order':'Mean order quantity','mean_reward':'Native team return','mean_occupancy':'Landmark occupancy'}
selected=[]
for ax,(setting,metric) in zip(axes.flat,specs):
 g=P[(P.setting==setting)&(P.metric==metric)]
 for c,color in zip(['null','lambda1','lambda7','lambda4'],['.25','#187b37','#b43c39','#b43c39']):
  z=g[g.condition==c].sort_values('w')
  if z.empty:continue
  ax.errorbar(z.w,z['mean'],yerr=[z['mean']-z.ci_low,z.ci_high-z['mean']],fmt='o-',ms=2.5,capsize=2,color=color,label=c)
 ax.set_title(setting.replace('_',' ')+( '*' if setting=='mpe_mappo' else ''),fontsize=8);ax.set_xlabel('w');ax.set_ylabel(labels[metric]);ax.legend(fontsize=6)
 family='supply' if setting.startswith('supply') else setting.split('_')[0]
 if not refdf.empty:
  for pol,color in [('inactive','.55'),('uniform_random','#9d71b5')]:
   r=refdf[(refdf.setting==family)&(refdf.policy==pol)&(refdf.metric==metric)]
   if len(r)==20:ax.axhline(r.value.mean(),ls='--',lw=.8,color=color);selected.append(dict(setting=setting,metric=metric,policy=pol,n=20,mean=r.value.mean()))
axes.flat[-1].axis('off');axes.flat[-1].text(0,1,'Solid: learned-policy cell means\nwith 95% seed-bootstrap intervals.\nDashed gray: inactive reference.\nDashed purple: uniform random.\n\nSupply: 300k; LBF: 2M.\nMPE*: historical budget unresolved.\n\nOrdering is recorded only for\nthe structural supply null sweep.\nNo transformed ordering or\nfood-count data are invented.',va='top',fontsize=8)
fig.savefig(OUT/'absolute_performance.pdf',bbox_inches='tight');fig.savefig(OUT/'absolute_performance.png',dpi=160,bbox_inches='tight');plt.close(fig)
pd.DataFrame(selected).to_csv(OUT/'reference_plot_lines.csv',index=False)
# Best observed mean performance among plotted cells, not a theoretical optimum.
rows=[]
for setting,metric in [('supply_ppo','profit'),('supply_mappo','profit'),('mpe_mappo','mean_reward'),('lbf_mappo','mean_reward')]:
 g=P[(P.setting==setting)&(P.metric==metric)];r=g.loc[g['mean'].idxmax()]
 rows.append(f'{setting.replace("_"," ")} & {r.condition} & {r.w:.2f} & {r["mean"]:.3f} [{r.ci_low:.3f},{r.ci_high:.3f}]')
table('performance_reference','Best observed cell mean among the plotted learned-policy conditions, chosen retrospectively by native return/profit. This is a descriptive learned reference, not an optimum; displayed intervals do not adjust for selection.','tab:performance_reference','Setting & Condition & $w$ & Native performance [95\\% CI]',rows,'@{}llrl@{}')
C=R('control_diagnostics_by_cell.csv');near=R('control_diagnostics_near_boundary.csv');rows=[]
for key,g in near.groupby(['control','arm','lambda_loss']):
 row=g.mean(numeric_only=True)
 rows.append(f'{key[0]}: {key[1].replace("_", " ")} & {int(key[2])} & '+','.join(f'{w:.2f}' for w in g.w)+f' & {row.frac_gain_mean:.3f} & {row.frac_loss_mean:.3f} & {row.mean_cpt_reward_mean:.2f} & {row.reward_std_mean:.2f} & {row.return_std_mean:.2f}')
table('sign_diagnostics','Final-policy evaluation diagnostics near each fitted control-arm crossing (equal-weight means over the two adjacent sampled cells, then policy seeds; five diagnostic episodes per policy). Nonnegative includes zero. Reward SD is the pre-transform blend SD, not transformed-reward or advantage SD. Return SD is within-policy episode-return SD, averaged across policies; neither SD is a pooled variance. Full cells, reference values and scaling factors are exported.','tab:sign_diagnostics',r'Control/arm & $\lambda$ & $w$ cells & Nonneg. & Negative & Mean $v$ & Blend SD & Return SD',rows,'@{}lrlrrrrr@{}')
print('Rendered threshold, performance and sign-diagnostic artifacts. Reference records:',len(refs))
if not refdf.empty:
 rng=np.random.default_rng(20260926);rows=[];summary=[]
 for (setting,policy,metric),g in refdf.groupby(['setting','policy','metric']):
  if metric not in ['profit','mean_reward','mean_occupancy']:continue
  x=g.value.to_numpy();ci=np.percentile(rng.choice(x,(2000,len(x)),replace=True).mean(1),[2.5,97.5])
  summary.append(dict(setting=setting,policy=policy,metric=metric,n=len(x),mean=x.mean(),ci_low=ci[0],ci_high=ci[1]))
  rows.append(f'{setting} & {policy.replace("_"," ")} & {metric.replace("_"," ")} & {len(x)} & {x.mean():.3f} [{ci[0]:.3f},{ci[1]:.3f}]')
 pd.DataFrame(summary).to_csv(OUT/'reference_summary.csv',index=False)
 table('reference_summary','Fresh reference policies: ten episodes per seed block and 2,000 seed-block bootstrap draws. Current-source configurations are described in the text. These intervals do not measure uncertainty in the historical configuration.','tab:reference_summary','Setting & Policy & Metric & Blocks & Mean [95\\% CI]',rows,'@{}lllr l@{}')

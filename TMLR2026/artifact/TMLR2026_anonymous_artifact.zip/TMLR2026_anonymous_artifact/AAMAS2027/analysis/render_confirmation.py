from pathlib import Path
import os,json
os.environ.setdefault('MPLCONFIGDIR','/private/tmp/aamas-matplotlib')
os.environ.setdefault('XDG_CACHE_HOME','/private/tmp/aamas-cache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd,numpy as np
from boundary import wilson,firth
r=Path(__file__).resolve().parents[1];out=r/'generated/confirmation';out.mkdir(exist_ok=True);audit=r/'audit/final_diagnostics'
f=pd.read_csv(audit/'fit_diagnostics.csv',keep_default_na=False);c=pd.read_csv(audit/'checked_contrasts.csv');cells=pd.read_csv(audit/'observed_cells.csv',keep_default_na=False);v=pd.read_csv(audit/'validated_evaluations.csv',keep_default_na=False)
plt.rcParams.update({'font.size':8,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
colors={'null':'#666666','curvature':'#2072ac','lambda7':'#bd5225','B':'#2072ac','A':'#bd5225','S':'#6554a4'}
labels={'null':'Linear','curvature':'Curvature only','lambda7':'Loss multiplier 7','B':'B: curvature only','A':'A: losses ×7','S':'S: both branches ×7'}
def save(fig,name):
 for ext in ['pdf','png']:fig.savefig(out/f'{name}.{ext}',dpi=180,bbox_inches='tight')
 plt.close(fig)
fig,axes=plt.subplots(1,2,figsize=(7,2.7),layout='constrained')
g=c[(c.kind=='horizon')&(c.episodes==10)&(c.contrast=='lambda7-curvature')].sort_values('budget');ax=axes[0];ax.errorbar(g.budget/1e6,g.difference,yerr=[g.difference-g.ci_low,g.ci_high-g.difference],fmt='o-',capsize=3,color=colors['A']);ax.axhline(0,color='.5',lw=.7,ls=':');ax.set(xlabel='Requested agent transitions (millions)',ylabel='λ=7 minus curvature-only crossing',title='(a) Independent horizon confirmation',xticks=[.3,.9,1.8,3.6])
ax=axes[1]
for i,contrast in enumerate(['A-B','S-B','A-S']):
 z=c[(c.kind=='control')&(c.contrast==contrast)].iloc[0];ax.errorbar(z.difference,i,xerr=[[z.difference-z.ci_low],[z.ci_high-z.difference]],fmt='o',capsize=3,color=['#bd5225','#6554a4','#222222'][i])
ax.axvline(0,color='.5',lw=.7,ls=':');ax.set(yticks=range(3),yticklabels=['Losses ×7 − baseline','Both ×7 − baseline','Asymmetric − symmetric'],xlabel='Crossing difference at 300k',title='(b) Direct scaling control');ax.invert_yaxis();save(fig,'confirmed_effects')
fig,axes=plt.subplots(1,3,figsize=(7,2.6),layout='constrained')
for ax,arm in zip(axes,['B','A','S']):
 z=cells[(cells.kind=='control')&(cells.arm==arm)];w=z.w.to_numpy();y=z.k/z.n;lo,hi=wilson(z.k.to_numpy(),z.n.to_numpy());ax.errorbar(w,y,yerr=[np.maximum(0,y-lo),np.maximum(0,hi-y)],fmt='o',capsize=2,color=colors[arm],ms=3);fit=firth(w,z.k.to_numpy(),z.n.to_numpy());x=np.linspace(0,1,200);ax.plot(x,1/(1+np.exp(-(fit['b0'][0]+fit['b1'][0]*x))),color=colors[arm]);ax.axhline(.5,ls=':',color='.5');ax.set(title=labels[arm],xlabel='Team-reward weight w',ylim=(-.04,1.04));
axes[0].set_ylabel('Collapse proportion');save(fig,'control_observations')
fig,ax=plt.subplots(figsize=(7,2.8),layout='constrained')
for arm in ['null','curvature','lambda7']:
 z=f[(f.kind=='horizon')&(f.arm==arm)&(f.episodes==10)].sort_values('budget');ax.errorbar(z.budget/1e6,z.w50,yerr=[z.w50-z.ci_low,z.ci_high-z.w50],fmt='.-',capsize=2,lw=.8,color=colors[arm],label=labels[arm]);deg=z[np.isclose(z.ci_low,z.ci_high)];ax.scatter(deg.budget/1e6,deg.w50,s=55,facecolors='none',edgecolors=colors[arm])
ax.set(xlabel='Requested agent transitions (millions)',ylabel='Crossing w₅₀');ax.legend(ncol=3,fontsize=7);save(fig,'horizon_all_checkpoints')
def table(name,caption,label,header,rows,spec):
 (out/f'{name}.tex').write_text('\\begin{table*}[t]\n\\centering\\small\n\\caption{'+caption+'}\n\\label{'+label+'}\n\\begin{tabular}{'+spec+'}\\toprule\n'+header+r' \\'+'\n\\midrule\n'+'\n'.join(row+r' \\' for row in rows)+'\n\\bottomrule\\end{tabular}\n\\end{table*}\n')
def ci(z,val='w50'):return f'${z[val]:.3f}$ $[{z.ci_low:.3f},{z.ci_high:.3f}]$'
rows=[]
for t in [300000,900000,1800000,3600000]:
 a=f[(f.kind=='horizon')&(f.budget==t)&(f.episodes==10)].set_index('arm');d=c[(c.kind=='horizon')&(c.budget==t)&(c.episodes==10)&(c.contrast=='lambda7-curvature')].iloc[0]
 rows.append(f'{t//1000}k & '+ ' & '.join(ci(a.loc[arm])+(r'$^{\dagger}$' if np.isclose(a.loc[arm].ci_low,a.loc[arm].ci_high) else '') for arm in ['null','curvature','lambda7'])+' & '+ci(d,'difference'))
table('horizon_table','Independent confirmation: ten seeds per condition and cell; 2,000 paired seed-block bootstrap draws. $\\dagger$ marks identical seed-label patterns and zero bootstrap width; the empirical bracket remains $[.6,.85]$. Intervals are pointwise.','tab:confirmed_horizon','Budget & Linear & Curvature & Loss multiplier 7 & Multiplier minus curvature',rows,'@{}rllll@{}')
rows=[]
for arm in ['B','A','S']:
 z=f[(f.kind=='control')&(f.arm==arm)].iloc[0];rows.append(arm+' & '+{'B':r'$\phi(u)$','A':r'$v_7(u)$','S':r'$7\phi(u)$'}[arm]+' & '+ci(z))
table('control_table','Direct control at 300k with common empirical-mean reference, eight mixture cells and ten seeds; Firth fits with 2,000 seed-block draws.','tab:confirmed_control','Arm & Transform & Crossing and 95\\% interval',rows,'@{}lll@{}')
# Recovery denominators retain mixture cells; no inference from pooling distinct cell probabilities.
seq=pd.read_csv(r/'generated/deadline_revision/horizon_confirmation/recovery_sequences.csv',keep_default_na=False);events=pd.read_csv(r/'generated/deadline_revision/horizon_confirmation/recovery_events.csv',keep_default_na=False);rows=[];summary=[]
for arm in ['null','curvature','lambda7']:
 for w in [.2,.4,.6,.85,1.]:
  s=seq[(seq.condition==arm)&(seq.w==w)];e=events[(events.condition==arm)&(events.w==w)&(events.requested==3600000)];nc=int(s.initial_collapsed.sum());nn=len(s)-nc;rec=int(e.recovered.sum());rel=int(e.relapsed.sum());sust=int((s.first_three_checkpoint_recovery!='').sum());fmt=lambda x,n:f'{x}/{n}' if n else '--';rows.append(f'{labels[arm]} & {w:g} & {nc} & {fmt(rec,nc)} & {fmt(sust,nc)} & {fmt(rel,nn)}');summary.append(dict(condition=arm,w=w,initial_collapsed=nc,recovered_3600k=rec,ever_sustained_recovery=sust,initial_noncollapsed=nn,relapsed_3600k=rel))
table('recovery_table','Within-policy outcomes conditional on the 300k label, by mixture cell. Recovery/relapse columns describe the 3.6M state. Sustained recovery means ever observing three consecutive noncollapsed checkpoints after 300k; it need not persist to 3.6M. A dash denotes a zero denominator.','tab:confirmed_recovery',r'Condition & $w$ & Collapsed at 300k & Recovered at 3.6M & Ever sustained & Relapsed at 3.6M',rows,'@{}lrrrrr@{}');pd.DataFrame(summary).to_csv(out/'recovery_summary.csv',index=False)
rows=[]
for t in [900000,1800000,3600000]:
 a=c[(c.kind=='horizon')&(c.budget==t)&(c.contrast=='lambda7-curvature')].set_index('episodes');rows.append(f'{t//1000}k & '+ci(a.loc[10],'difference')+' & '+ci(a.loc[50],'difference'))
table('evaluation_table','Loss-multiplier-minus-curvature contrast under ten versus fifty evaluation episodes. Only one of 450 trajectory/checkpoint labels changes (curvature, $w=.4$, seed 51, 900k). The fifty episodes include the original ten and are a sensitivity check, not an independent replication.','tab:confirmed_eval','Budget & Ten episodes & Fifty episodes',rows,'@{}rll@{}')
print(pd.DataFrame(summary).groupby('condition').sum(numeric_only=True).to_string())
fig,axes=plt.subplots(1,2,figsize=(7,2.6),layout='constrained')
for arm in ['null','curvature','lambda7']:
 g=events[events.condition==arm]
 for ax,metric,base in [(axes[0],'recovered',True),(axes[1],'relapsed',False)]:
  z=g[g.initial_collapsed==base].groupby('requested')[metric].agg(['sum','count']);ax.plot(z.index/1e6,z['sum']/z['count'],'.-',color=colors[arm],label=f'{labels[arm]} (n={int(z["count"].iloc[0])})',lw=1,ms=3)
for ax,title in zip(axes,['Recovered among collapsed at 300k','Relapsed among noncollapsed at 300k']):ax.set(title=title,xlabel='Requested agent transitions (millions)',ylabel='Observed fraction',ylim=(-.01,.4));ax.legend(fontsize=6.5)
save(fig,'recovery_trajectories')
rows=[]
for t in [300000,900000,1800000,3600000]:
 for arm in ['null','curvature','lambda7']:
  z=cells[(cells.kind=='horizon')&(cells.budget==t)&(cells.episodes==10)&(cells.arm==arm)].sort_values('w');rows.append(f'{t//1000}k & {labels[arm]} & '+' & '.join(f'{int(k)}/10' for k in z.k))
table('horizon_cells','Observed collapsed/total counts for the independent horizon confirmation at the four primary budgets. The same ten seeds occur at every cell and budget. All 24 checkpoint panels remain in the raw exports.','tab:confirmed_cells',r'Budget & Condition & $w=.2$ & $.4$ & $.6$ & $.85$ & $1$',rows,'@{}rlrrrrr@{}')

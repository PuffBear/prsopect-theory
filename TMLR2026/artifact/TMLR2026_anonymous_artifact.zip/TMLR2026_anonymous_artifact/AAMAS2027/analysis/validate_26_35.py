from pathlib import Path
import json
import numpy as np,pandas as pd
r=Path(__file__).resolve().parents[1];out=r/'generated/pointers26_35'
d=pd.read_csv(out/'decimation_replicates.csv');s=pd.read_csv(out/'decimation_summary.csv')
assert len(d)==9624 and len(s)==72
assert (d.usable_bootstrap<=500).all() and (d.runs<=d.full_runs).all()
for row in d.itertuples():
 seeds=json.loads(row.seed_ids);grid=json.loads(row.grid)
 assert len(seeds)==row.seeds and len(set(seeds))==row.seeds
 assert sorted(grid)==grid
 if row.rule=='full' and row.seeds==20:assert row.absolute_error<1e-12
q=pd.read_csv(out/'unit_coordinate.csv');assert len(q)==9 and (q.usable==2000).all()
np.testing.assert_allclose(q.q,q.wcrit*q.c_global/((1-q.wcrit)*q.c_local+q.wcrit*q.c_global))
b=pd.read_csv(out/'rms_control_differences.csv');assert len(b)==2 and (b.usable==2000).all()
assert b.loc[b.arm=='stdmatched','ci_low'].iloc[0]>0
report=dict(decimation_point_fits=len(d),bootstrap_fits=len(d)*500,common_q_fits=len(q),rms_control_contrasts=len(b),zero_width_subset_intervals=int((d.ci_width==0).sum()),note='zero empirical-bootstrap width can reflect identical observed seed patterns, not certainty or ground-truth coverage')
(out/'validation.json').write_text(json.dumps(report,indent=2));print('PASS',json.dumps(report))

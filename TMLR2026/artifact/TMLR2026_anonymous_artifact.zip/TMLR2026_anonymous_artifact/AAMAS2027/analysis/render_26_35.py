from pathlib import Path
import pandas as pd,numpy as np,json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'generated/pointers26_35'
def table(name,caption,label,head,rows,spec):
 (OUT/(name+'.tex')).write_text('\\begin{table*}[t]\n\\caption{'+caption+'}\n\\label{'+label+'}\n\\centering\\small\n\\begin{tabular}{'+spec+'}\n\\toprule\n'+head+r' \\'+'\n\\midrule\n'+'\n'.join(r+r' \\' for r in rows)+'\n\\bottomrule\n\\end{tabular}\n\\end{table*}\n')
R=pd.read_csv(OUT/'decimation_summary.csv');names={'supply_ppo':'Supply PPO','supply_mappo':'Supply MAPPO','mpe_mappo':'MPE*','lbf_mappo':'LBF'}
for rule in ['even','odd']:
 rows=[]
 for r in R[R.rule==rule].itertuples():
  rows.append(f'{names[r.setting]} & {r.condition.replace("lambda", "")} & {r.seeds} & {r.replicates} & {r.median_runs:.0f} & {100*r.run_reduction:.0f}\\% & {r.median_error:.3f}/{r.p90_error:.3f} & {r.median_ci_width:.3f} & {100*r.failure_to_bracket:.1f}\\%')
 table('decimation_'+rule,'Fixed grid thinning ('+rule+' parity): endpoints plus alternating interior cells, compared with each condition\'s full-data fit. Five/ten-seed rows use 200 subsets; twenty seeds has one possible subset. CI widths use 500 seed-block draws per subset. Error is descriptive agreement with the full-data estimate, not coverage against truth. Zero bootstrap widths can reflect identical empirical seed patterns, not certainty. MPE* remains provisional.','tab:decimation_'+rule,r'Setting & $\lambda$ & Seeds & Subsets & Runs & Saved & Error med./90th & CI width med. & No bracket',rows,'@{}lrrrrrlll@{}')
Q=pd.read_csv(OUT/'unit_coordinate.csv');D=pd.read_csv(OUT/'unit_coordinate_differences.csv');rows=[]
for r in Q.itertuples():
 d=D[(D.arm==r.arm)&(D.lambda_loss==r.lambda_loss)]
 contrast='--' if d.empty else f'{d.iloc[0].difference:+.3f} [{d.iloc[0].ci_low:+.3f},{d.iloc[0].ci_high:+.3f}]'
 rows.append(f'{r.arm} & {int(r.lambda_loss)} & {r.c_local:.0f},{r.c_global:.0f} & {r.wcrit:.3f} & {r.q:.3f} [{r.ci_low:.3f},{r.ci_high:.3f}] & {contrast}')
table('unit_coordinate','Control C on the common effective team-weight coordinate $q=wc_g/[(1-w)c_\\ell+wc_g]$, using revised Firth fits and 2,000 seed-block draws. Differences pair the recorded seed identifiers with baseline; they do not establish identical environment streams.','tab:unit_q',r'Arm & $\lambda$ & $c_\ell,c_g$ & $w_{50}$ & $q(w_{50})$ [95\% CI] & Difference from baseline [CI]',rows,'@{}lrrlll@{}')
print('Rendered fixed-grid and common-coordinate tables')

"""Fail-closed pilot validation and the predeclared common-grid refinement rule."""
import argparse, hashlib, json, math
from pathlib import Path
WS=[0.,.4,.5,.6,.7,.85,1.]
CONDITIONS=['null','curvature','lambda7']
BUDGETS=[150000,300000,450000,900000,1800000,3600000]

def inspect(roots):
 records={};hashes={};counts={};elapsed=[]
 for root in roots:
  for p in Path(root).rglob('evaluation_*.json'):
   cfg=json.loads((p.parent/'protocol.json').read_text())
   if cfg.get('phase')!='pilot' or cfg.get('version')!='explicit-demand-v2':raise ValueError(f'Not a v2 pilot: {p}')
   r=json.loads(p.read_text());t=r['requested_checkpoint'];key=(cfg['condition'],cfg['w'],cfg['seed'],t)
   if key in records:raise ValueError(f'Duplicate trajectory checkpoint: {key}')
   if r['actual_agent_transitions']!=math.ceil(t/640)*640:raise ValueError(f'Counter mismatch: {p}')
   if t not in cfg['checkpoints']:raise ValueError(f'Undeclared checkpoint: {p}')
   for name,n in [('primary',10)]+([('sensitivity_50',50)] if t in [900000,1800000,3600000] else []):
    x=r if name=='primary' else r[name];s=x['summary']
    if len(x['episodes'])!=n:raise ValueError(f'Episode count: {p}')
    if [e['evaluation_seed'] for e in x['episodes']]!=list(range(10*cfg['seed'],10*cfg['seed']+n)):raise ValueError(f'Evaluation seeds: {p}')
    if bool(s['collapsed'])!=(s['mean_S']<10 and s['profit']<=-127.1):raise ValueError(f'Label mismatch: {p}')
    for metric in ['profit','mean_order','lost_sales','trajectory_mean_S']:
     mean=sum(e[metric] for e in x['episodes'])/n
     if not math.isclose(mean,s[metric],rel_tol=1e-9,abs_tol=1e-9):raise ValueError(f'Summary mismatch: {p}:{metric}')
   manifest=json.loads((p.parent/'manifest.json').read_text())
   for source,digest in manifest['v2_sources'].items():
    if source in hashes and hashes[source]!=digest:raise ValueError(f'Mixed sources: {source}')
    hashes[source]=digest
   records[key]=r;counts[t]=counts.get(t,0)+1
   if t==900000:elapsed.append(r['elapsed_seconds'])
 expected={(c,w,s,t) for c in CONDITIONS for w in WS for s in range(100,105) for t in range(150000,3600001,150000)}
 missing=sorted(expected-set(records));unexpected=sorted(set(records)-expected)
 report={'completed_checkpoints':counts,'validated_records':len(records),'missing_checkpoint_count':len(missing),'missing_checkpoints':missing,'unexpected':unexpected,'source_hashes':hashes,'pilot_only':True}
 if elapsed:report['observed_900k_seconds']={'minimum':min(elapsed),'mean':sum(elapsed)/len(elapsed),'maximum':max(elapsed),'n':len(elapsed)}
 if missing or unexpected:report['status']='incomplete; confirmation grid not frozen';return report
 brackets=[]
 for t in BUDGETS:
  for ci,c in enumerate(CONDITIONS):
   props=[sum(records[c,w,s,t]['summary']['collapsed'] for s in range(100,105))/5 for w in WS]
   found=[]
   for a,b,pa,pb in zip(WS[:-1],WS[1:],props[:-1],props[1:]):
    if min(pa,pb)<=.5<=max(pa,pb):found.append({'condition':c,'condition_order':ci,'budget':t,'lower':a,'upper':b,'width':round(b-a,12)})
   brackets.extend(found)
   if not found:brackets.append({'condition':c,'condition_order':ci,'budget':t,'unlocalized':True})
 candidates=sorted([b for b in brackets if b.get('width',0)>.05],key=lambda b:(-b['width'],b['budget'],b['condition_order'],b['lower']))
 report['brackets']=brackets;report['base_grid']=WS
 if candidates:
  chosen=candidates[0];mid=(chosen['lower']+chosen['upper'])/2
  report.update(status='refinement required before confirmation',selected_bracket=chosen,added_w=mid,proposed_grid=sorted(WS+[mid]),required_refinement_trajectories=15,required_extra_calibration_policies=5)
 else:report.update(status='base pilot complete; grid eligible for freeze',proposed_grid=WS)
 return report

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',action='append',required=True);p.add_argument('--out',required=True);a=p.parse_args()
 r=inspect(a.root);out=Path(a.out);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(r,indent=2));print(r['status'])

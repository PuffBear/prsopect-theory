from pathlib import Path
import numpy as np,pandas as pd,json
from reanalyze import sensitivity
root=Path(__file__).resolve().parents[1];out=root/'audit/final_diagnostics';d=pd.read_csv(out/'validated_evaluations.csv',keep_default_na=False);f=pd.read_csv(out/'fit_diagnostics.csv',keep_default_na=False);rows=[]
for (kind,t,arm),g in d[(d.episodes==10)&d.budget.isin([300000,900000,1800000,3600000])].groupby(['kind','budget','arm']):
 rows.extend(sensitivity(g,dict(kind=kind,budget=t,arm=arm)))
s=pd.DataFrame(rows);s.to_csv(out/'estimator_sensitivity.csv',index=False);summaries=[]
for key,g in s.groupby(['kind','budget','arm']):
 point=f[(f.kind==key[0])&(f.budget==key[1])&(f.arm==key[2])&(f.episodes==10)].iloc[0].w50
 values=[point]+g.loc[g.status.isin(['ok','plateau']),'wcrit'].tolist();summaries.append(dict(kind=key[0],budget=key[1],arm=key[2],spread=max(values)-min(values),available_estimators=len(values)))
pd.DataFrame(summaries).to_csv(out/'estimator_spread.csv',index=False)
print(pd.DataFrame(summaries).sort_values('spread',ascending=False).head(5).to_string(index=False))
for kind,t,hi,lo in [('control',300000,'A','S'),('horizon',3600000,'lambda7','curvature')]:
 for estimator in ['logistic','probit','isotonic']:
  g=s[(s.kind==kind)&(s.budget==t)&(s.estimator==estimator)].set_index('arm');print(kind,t,estimator,'point difference',g.loc[hi,'wcrit']-g.loc[lo,'wcrit'])

"""Canonical post-review analysis for checklist 6--15. Never writes legacy data.
Run from any directory with the AAMAS environment. Fixed-label 2000-seed-block
bootstrap, Firth primary; logistic/probit/isotonic sensitivity on the same rows.
"""
from pathlib import Path
import csv,json,hashlib,itertools,warnings,sys
import numpy as np
import pandas as pd
from scipy.special import expit
from sklearn.isotonic import IsotonicRegression
import statsmodels.api as sm
from boundary import firth,wilson
ROOT=Path(__file__).resolve().parents[2]; OUT=ROOT/'AAMAS2027/generated'; OUT.mkdir(exist_ok=True)
B=2000; RNG_SEED=20260926
SOURCES=[
 ('supply_ppo','expN_figures/expN_raw_data.csv',300000,'null'),
 ('supply_ppo','expB_reduced_figures/expB_reduced_raw_data.csv',300000,None),
 ('supply_ppo','expPPO_lambda_sweep_figures/ppo_lambda_sweep_raw_data.csv',300000,None),
 ('supply_ppo','expHighLambda_finegrid_figures/highlambda_finegrid_raw_data.csv',300000,None),
 ('supply_mappo','expMAPPO_orgym_figures/mappo_orgym_raw_data.csv',300000,None),
 ('mpe_mappo','expMAPPO_mpe_figures/mappo_mpe_v2_raw_data.csv',None,None),
 ('mpe_mappo','expMAPPO_mpe_figures/mappo_mpe_lambda_sweep_raw_data.csv',None,None),
 ('lbf_mappo','expMAPPO_lbf_figures/mappo_lbf_raw_data.csv',2000000,None),
 ('lbf_mappo','expMAPPO_lbf_figures/mappo_lbf_loww_raw_data.csv',2000000,None),
 ('lbf_mappo','expMAPPO_lbf_figures/mappo_lbf_highw_raw_data.csv',2000000,None),
 ('supply_horizon','expA_figures/expA_raw_data.csv',150000,'null'),
 ('supply_horizon','expA300k_figures/expA300k_raw_data.csv',300000,'null'),
 ('supply_horizon','expHorizon_extra_figures/horizon_extra_raw_data.csv',None,'null')]

def load():
    rows=[]; exclusions=[]; inventory=[]; hashes={}
    scheduled=[180,300,400,120,700,660,1100,960,480,160,220,140,320]
    for (setting,rel,budget,forced),expected in zip(SOURCES,scheduled):
        path=ROOT/'docs'/rel; source=str(path.relative_to(ROOT)); hashes[source]=hashlib.sha256(path.read_bytes()).hexdigest()
        raw=list(csv.DictReader(path.open())); valid=0; excluded=0; outscope=0
        for line,r in enumerate(raw,2):
            try:
                w=float(r['w']); seed=int(float(r['seed'])); lam=float(r.get('lambda_loss',r.get('lambda',1)))
                condition=forced or ('null' if r.get('condition')=='null' else f'lambda{int(lam)}')
                t=budget or (int(r['horizon']) if setting=='supply_horizon' else -1)
                if setting=='supply_horizon' and (t not in [150000,300000,450000,900000] or float(r.get('alpha',1))!=1):
                    outscope+=1;continue
                if setting.startswith('supply'):
                    metric=float(r['mean_S']);profit=float(r['profit']);y=int(metric<10 and profit<=-127.1)
                else:
                    metric=float(r['mean_occupancy' if setting=='mpe_mappo' else 'mean_reward']);profit=np.nan
                    y=int(metric<(.144 if setting=='mpe_mappo' else .626))
                if not np.isfinite([w,seed,lam,metric]).all():raise ValueError('non-finite required field')
                config=f'{setting}:{t}'
                # Unknown MPE historical horizon is not silently set to one common budget.
                if setting=='mpe_mappo':config+=':'+('v2_unverified' if 'v2_' in rel else 'fill_unverified')
                rows.append(dict(setting=setting,configuration=config,budget=t,condition=condition,lambda_loss=lam,w=w,seed=seed,y=y,metric=metric,profit=profit,source=source,source_line=line))
                valid+=1
            except (ValueError,TypeError,KeyError) as e:
                excluded+=1;exclusions.append(dict(source=source,line=line,reason=str(e),raw=json.dumps(r)))
        inventory.append(dict(source=source,scheduled_rows=expected,scheduled_basis='declared source grids; 20 seeds per cell',recorded_rows=len(raw),completed_valid_results=valid+outscope,completion_basis='valid saved observation; scheduler completion not recovered',in_scope_valid=valid,excluded=excluded,out_of_scope=outscope))
    df=pd.DataFrame(rows); keys=['configuration','condition','w','seed']
    dup=df.duplicated(keys,keep=False)
    if dup.any():
        for _,g in df[dup].groupby(keys):
            if len(g[['y','metric','profit']].drop_duplicates())>1:raise ValueError('Conflicting duplicate cell: '+g.to_json())
    df[dup].to_csv(OUT/'duplicate_rows.csv',index=False)
    df=df.drop_duplicates(keys).reset_index(drop=True)
    for row in inventory:row['unique_retained']=int((df.source==row['source']).sum())
    pd.DataFrame(inventory).to_csv(OUT/'run_inventory.csv',index=False)
    pd.DataFrame(exclusions,columns=['source','line','reason','raw']).to_csv(OUT/'excluded_rows.csv',index=False)
    missing=[]
    for (setting,condition,budget),g in df.groupby(['setting','condition','budget']):
        for w,seed in itertools.product(sorted(g.w.unique()),range(42,62)):
            if not ((g.w==w)&(g.seed==seed)).any():missing.append(dict(setting=setting,condition=condition,budget=budget,w=w,seed=seed))
    pd.DataFrame(missing,columns=['setting','condition','budget','w','seed']).to_csv(OUT/'missing_cells.csv',index=False)
    (OUT/'input_hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
    df.to_csv(OUT/'canonical_runs.csv',index=False)
    return df

def calibration(df):
    out={}
    for setting in ['mpe_mappo','lbf_mappo']:
        d=df[df.setting==setting]; null=d[d.condition=='null']; wmin=d.w.min();wmax=d.w.max()
        low=d[(d.w==wmin)&(d.condition==('null' if setting=='mpe_mappo' else 'lambda7'))].metric.mean()
        high=null[null.w==wmax].metric.mean()
        out[setting]=dict(low_reference=low,high_reference=high,midpoint=(low+high)/2,fixed_analysis_threshold=.144 if setting=='mpe_mappo' else .626,
            chronology='retrospective calibration; no prospective registration established',low_arm='null' if setting=='mpe_mappo' else 'lambda7')
    (OUT/'calibration.json').write_text(json.dumps(out,indent=2)+'\n')

def matrices(g,seeds):
    ws=np.sort(g.w.unique());n=np.zeros((len(seeds),len(ws)));k=n.copy()
    for r in g.itertuples():
        i=seeds.index(r.seed);j=np.searchsorted(ws,r.w);n[i,j]+=1;k[i,j]+=r.y
    return ws,k,n

def sensitivity(g,base):
    w=g.w.to_numpy();y=g.y.to_numpy();out=[]
    # Linear separability including quasi-separation (touching support endpoints).
    separated=len(np.unique(y))<2 or (w[y==1].max()<=w[y==0].min() or w[y==0].max()<=w[y==1].min())
    for name,link in [('logistic',sm.families.links.Logit()),('probit',sm.families.links.Probit())]:
        row=dict(estimator=name,wcrit=np.nan,lower=np.nan,upper=np.nan,status='separated' if separated else 'failed')
        if not separated:
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter('error');fit=sm.GLM(y,sm.add_constant(w),family=sm.families.Binomial(link=link)).fit(maxiter=200,tol=1e-10)
                if fit.converged and abs(fit.params[1])>1e-9:
                    wc=-fit.params[0]/fit.params[1];row.update(wcrit=wc,lower=wc,upper=wc,status='ok')
            except (Exception,) as e:row['status']=type(e).__name__
        out.append(row)
    cells=g.groupby('w').y.agg(['sum','count']);x=cells.index.to_numpy();p=IsotonicRegression(increasing=False).fit_transform(x,cells['sum']/cells['count'],sample_weight=cells['count'])
    equal=np.isclose(p,.5,atol=1e-12); lo=hi=np.nan;status='not_bracketed'
    if equal.any():lo=x[equal].min();hi=x[equal].max();status='plateau' if lo!=hi else 'ok'
    elif (p>.5).any() and (p<.5).any():
        j=np.flatnonzero(p<.5)[0];lo=hi=x[j-1]+(.5-p[j-1])*(x[j]-x[j-1])/(p[j]-p[j-1]);status='ok'
    out.append(dict(estimator='isotonic',wcrit=(lo+hi)/2,lower=lo,upper=hi,status=status))
    for r in out:r.update(base)
    return out

def run():
    df=load();calibration(df);rng=np.random.default_rng(RNG_SEED);seeds=list(range(42,62))
    weights=rng.multinomial(20,np.full(20,1/20),size=B)
    pd.DataFrame(weights,columns=[f'seed_{s}' for s in seeds]).to_csv(OUT/'bootstrap_seed_multiplicities.csv',index=False)
    records=[];cells=[];sens=[];draws=[];saved={};groups={}
    for (setting,budget,condition),g in df.groupby(['setting','budget','condition'],sort=True):
        print(setting,budget,condition,flush=True);ws,k,n=matrices(g,seeds)
        point=firth(ws,k.sum(0),n.sum(0));boot=firth(ws,weights@k,weights@n)
        group=(setting,budget,condition);saved[group]=boot;groups[group]=(ws,k,n)
        wc=point['wcrit'][0];finite=np.isfinite(boot['wcrit']);ci=np.percentile(boot['wcrit'][finite],[2.5,97.5]) if finite.any() else [np.nan,np.nan]
        proportions=k.sum(0)/n.sum(0)
        bracket=[(float(ws[i]),float(ws[i+1])) for i in range(len(ws)-1) if proportions[i]>=.5 and proportions[i+1]<=.5]
        base=dict(setting=setting,budget=budget,condition=condition,lambda_loss=float(g.lambda_loss.iloc[0]))
        row=dict(**base,n=len(g),n_seeds=g.seed.nunique(),w_min=ws.min(),w_max=ws.max(),wcrit=wc,ci_low=ci[0],ci_high=ci[1],b0=point['b0'][0],b1=point['b1'][0],fit_status=point['status'][0],in_grid=point['in_grid'][0],brackets=json.dumps(bracket),bootstrap_requested=B,bootstrap_usable=int(finite.sum()),bootstrap_nonconverged=int((~boot['converged']).sum()),bootstrap_unidentified=int((boot['status']!='ok').sum()),bootstrap_outside_grid=int((finite&~boot['in_grid']).sum()),provenance='provisional mixed/unverified MPE configuration' if setting=='mpe_mappo' else 'available legacy data; source-audited')
        records.append(row)
        for i in range(B):
            draws.append(dict(**base,replicate=i,b0=boot['b0'][i],b1=boot['b1'][i],wcrit=boot['wcrit'][i],status=boot['status'][i],in_grid=boot['in_grid'][i]))
        for j,w in enumerate(ws):
            count=int(n[:,j].sum());success=int(k[:,j].sum());lo,hi=wilson(success,count)
            cells.append(dict(**base,configuration=';'.join(g.configuration.unique()),w=w,k=success,n=count,proportion=success/count,ci_low=lo,ci_high=hi,source=';'.join(g[g.w==w].source.unique())))
        sens.extend(sensitivity(g,base));sens.append(dict(**base,estimator='firth',wcrit=wc,lower=wc,upper=wc,status=point['status'][0]))
    fits=pd.DataFrame(records);fits.to_csv(OUT/'boundary_estimates.csv',index=False)
    pd.DataFrame(cells).to_csv(OUT/'collapse_cells.csv',index=False)
    pd.DataFrame(draws).to_csv(OUT/'bootstrap_draws.csv',index=False)
    pd.DataFrame(sens).to_csv(OUT/'estimator_sensitivity.csv',index=False)
    contrasts=[];contrastdraws=[]
    # Endpoint comparisons plus supply decomposition, always on the same seed draws.
    specs=[('supply_ppo',300000,'lambda1','lambda7'),('supply_mappo',300000,'lambda1','lambda7'),('mpe_mappo',-1,'lambda1','lambda7'),('lbf_mappo',2000000,'lambda1','lambda4')]
    specs += [('supply_ppo',300000,'null',f'lambda{x}') for x in [1,3,7]]+[('supply_ppo',300000,'lambda1','lambda3')]
    for setting,budget,low,high in specs:
        a=(setting,budget,low);b=(setting,budget,high)
        point=float(fits[(fits.setting==setting)&(fits.budget==budget)&(fits.condition==high)].wcrit.iloc[0]-fits[(fits.setting==setting)&(fits.budget==budget)&(fits.condition==low)].wcrit.iloc[0])
        for pairing in ['paired','independent']:
            if pairing=='paired':av=saved[a]['wcrit'];bv=saved[b]['wcrit']
            else:
                wa,ka,na=groups[a];wb,kb,nb=groups[b]
                weights_a=rng.multinomial(20,np.full(20,.05),size=B);weights_b=rng.multinomial(20,np.full(20,.05),size=B)
                av=firth(wa,weights_a@ka,weights_a@na)['wcrit'];bv=firth(wb,weights_b@kb,weights_b@nb)['wcrit']
            delta=bv-av;valid=np.isfinite(delta);ci=np.percentile(delta[valid],[2.5,97.5]) if valid.any() else [np.nan,np.nan]
            contrasts.append(dict(setting=setting,budget=budget,low=low,high=high,pairing=pairing,difference=point,ci_low=ci[0],ci_high=ci[1],usable=int(valid.sum()),requested=B,status='descriptive only: MPE provenance unresolved' if setting=='mpe_mappo' else 'fixed-label interval'))
            for i in range(B):contrastdraws.append(dict(setting=setting,low=low,high=high,pairing=pairing,replicate=i,low_wcrit=av[i],high_wcrit=bv[i],difference=delta[i],usable=bool(valid[i])))
    pd.DataFrame(contrasts).to_csv(OUT/'endpoint_differences.csv',index=False);pd.DataFrame(contrastdraws).to_csv(OUT/'contrast_bootstrap_draws.csv',index=False)
    (OUT/'analysis_metadata.json').write_text(json.dumps(dict(bootstrap_replicates=B,random_seed=RNG_SEED,primary_estimator='Firth logistic, Jeffreys penalty',bootstrap='training-seed block percentile; fixed labels; no clipping; finite-replicate counts explicit',mpe='descriptive only, historical budgets and wrapper unresolved',isotonic='decreasing weighted PAVA, linear interpolation, plateau interval retained; midpoint used only for comparison'),indent=2)+'\n')
    print(pd.DataFrame(contrasts).to_string(index=False),flush=True)

if __name__=='__main__':run()

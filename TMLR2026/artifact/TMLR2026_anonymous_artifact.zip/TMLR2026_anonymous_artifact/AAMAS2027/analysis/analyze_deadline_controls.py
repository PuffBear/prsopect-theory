"""Analyze the frozen three-arm deadline design without pooling pilot seeds."""
from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
from boundary import firth
root=Path(__file__).resolve().parents[1]; dp=root/'orchestration_deadline_v1/design.json';d=json.loads(dp.read_text());out=root/'generated/deadline_revision/control_analysis';out.mkdir(parents=True,exist_ok=True)
rows=[]
for p in sorted((root/'new_runs/deadline_confirmation_v1/control').glob('run_*')):
 c=json.loads((p/'protocol.json').read_text());r=json.loads((p/'evaluation_300000.json').read_text());lineage=json.loads((p/'lineage.json').read_text())
 assert lineage['design_sha256']==hashlib.sha256(dp.read_bytes()).hexdigest()
 assert c['phase']=='confirmation' and c['reference']==d['reference'] and c['c']==(7 if c['arm']=='S' else 1)
 assert r['actual_agent_transitions']==300160 and len(r['episodes'])==10
 assert [e['evaluation_seed'] for e in r['episodes']]==list(range(c['seed']*10,c['seed']*10+10))
 rows.append(dict(arm=c['arm'],w=c['w'],seed=c['seed'],collapsed=int(r['summary']['collapsed'])))
f=pd.DataFrame(rows);keys=list(zip(f.arm,f.w,f.seed));assert len(keys)==len(set(keys))==240
assert set(keys)=={(a,w,s) for a in d['control_arms'] for w in d['control_grid'] for s in d['seeds']}
f.to_csv(out/'runs.csv',index=False)
weights=np.random.default_rng(20260927).multinomial(10,np.full(10,.1),size=2000);fits={};results=[];cells=[]
for arm in d['control_arms']:
 h=f[f.arm==arm];k=h.pivot(index='seed',columns='w',values='collapsed').reindex(index=d['seeds'],columns=d['control_grid']).to_numpy();w=np.array(d['control_grid']);n=np.ones_like(k)
 point=firth(w,k.sum(0),n.sum(0));boot=firth(w,weights@k,weights@n);z=boot['wcrit'];ok=np.isfinite(z);ci=np.percentile(z[ok],[2.5,97.5]);fits[arm]=(point['wcrit'][0],z)
 results.append(dict(arm=arm,w50=point['wcrit'][0],ci_low=ci[0],ci_high=ci[1],usable=int(ok.sum()),in_grid=bool(point['in_grid'][0])))
 cells.extend(dict(arm=arm,w=float(x),collapsed=int(y),n=10) for x,y in zip(w,k.sum(0)))
contrasts=[]
for high,low in [('A','S'),('A','B'),('S','B')]:
 p,z=fits[high];q,v=fits[low];delta=z-v;ok=np.isfinite(delta);ci=np.percentile(delta[ok],[2.5,97.5]);contrasts.append(dict(contrast=high+'-'+low,difference=p-q,ci_low=ci[0],ci_high=ci[1],usable=int(ok.sum())))
pd.DataFrame(results).to_csv(out/'boundaries.csv',index=False);pd.DataFrame(cells).to_csv(out/'cells.csv',index=False);pd.DataFrame(contrasts).to_csv(out/'contrasts.csv',index=False)
print(json.dumps(dict(boundaries=results,contrasts=contrasts),indent=2))

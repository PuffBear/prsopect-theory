from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1];out=root/'generated'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record={'input_files':json.loads((out/'input_hashes.json').read_text()),
        'analysis_files':{str(p.relative_to(root)):sha(p) for p in sorted((root/'analysis').glob('*')) if p.is_file()},
        'generated_files':{str(p.relative_to(root)):sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='generated_artifact_manifest.json'},
        'lineage':'reanalyze.py reads declared SOURCES; render_results.py reads canonical fit/cell/contrast/sensitivity exports; generated .tex and figures are included by main/supplement sources',
        'scope':'primary supply, linear supply horizons and transfer reanalysis; MPE is descriptive pending provenance; unrecomputed legacy control/scope displays remain historical; pointers36_40 regenerates shared-actor minority fits/paired contrasts; pointers16_25 adds fixed-label sensitivity, absolute performance, fresh reference evaluations and saved reward diagnostics; pointers26_35 adds fixed-grid thinning, common-unit q, RMS refits and compute accounting'}
(out/'generated_artifact_manifest.json').write_text(json.dumps(record,indent=2)+'\n')
print('Recorded',len(record['generated_files']),'generated artifact hashes')

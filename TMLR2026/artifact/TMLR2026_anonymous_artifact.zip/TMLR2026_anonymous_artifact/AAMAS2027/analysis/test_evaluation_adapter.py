"""Contract test for exclusion of final reset actions from trajectory diagnostics."""
import sys,types
import numpy as np
from evaluate_supply import evaluate_with_trajectory_metric
fake=types.ModuleType('expA_interior_w');fake.LOW_BOUND=0;fake.HIGH_BOUND=500
class Env:agents=list(range(5))
class Policy:
    def predict(self,obs,deterministic=True):return np.array([obs]),None
def evaluate(model,env,num_episodes,base_seed):
    for _ in range(10):model.predict(0.)
    for _ in range(5):model.predict(1.)
    return 500,1,2,.3,-128.1,4
fake.evaluate_and_extract_metrics=evaluate
sys.modules['expA_interior_w']=fake
r=evaluate_with_trajectory_metric(Policy(),Env())
assert r['mean_S']==500 and r['trajectory_mean_S']==250
assert r['trajectory_action_count']==10 and r['collapsed']==False
print('PASS: trajectory statistic excludes reset statistic; original metric/label preserved')

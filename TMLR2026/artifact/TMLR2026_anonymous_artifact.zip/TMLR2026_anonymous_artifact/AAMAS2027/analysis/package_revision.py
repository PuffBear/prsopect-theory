"""Package the exact verified manuscript inputs; never replace the submission archive."""
from pathlib import Path
import hashlib,json,zipfile,tempfile,subprocess
ROOT=Path(__file__).resolve().parents[1];dest=ROOT/'package';dest.mkdir(exist_ok=True)
files=set()
for doc in ['main','supplement']:
 for line in (ROOT/f'build/{doc}.fls').read_text().splitlines():
  if not line.startswith('INPUT '):continue
  p=Path(line[6:]);p=p if p.is_absolute() else ROOT/p;p=p.resolve()
  if p.is_relative_to(ROOT) and p.is_file() and 'build' not in p.relative_to(ROOT).parts and p.suffix in ['.tex','.pdf','.png','.jpg','.cls','.bst','.bib']:files.add(p)
for name in ['main.tex','supplement.tex','aamas-preamble.tex','aamas.cls','ACM-Reference-Format.bst','references.bib','Makefile','README.md','build/main.pdf','build/supplement.pdf','audit/REMAINING_WORK.md','audit/accounting/ACCOUNTING_REPORT.md','audit/accounting/group_accounting.csv','audit/accounting/job_accounting.csv','audit/accounting/run_reconciliation.json','audit/CONFIRMATION_INTEGRATION.md','audit/final_diagnostics/FINAL_DIAGNOSTIC_REPORT.md','audit/DEADLINE_REVISION_STATUS.md','audit/LIVE_EXPERIMENT_STATUS.json','orchestration_deadline_v1/design.json','audit/remaining_work.csv','audit/POINTERS_36_TO_40.md','audit/REVIEWER_RESPONSE.md','audit/reviewer_response_matrix.csv','audit/revision_locations.csv','audit/asset_inventory.csv','generated/pointers36_40/scope_boundaries.csv','generated/pointers36_40/scope_contrasts.csv','generated/pointers36_40/scope_cells.csv','generated/pointers36_40/provenance.json','generated/pointers36_40/validation.json']:
 p=ROOT/name;assert p.is_file(),p;files.add(p)
manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
note='Interim AAMAS manuscript package. Run make all to rebuild. This contains current manuscript sources/assets and selected audit exports, not the complete training/data environment. It does not certify unresolved experiments or legacy numerical lineage. Read audit/REMAINING_WORK.md before use. Frozen AAAI files are not overwritten.\n'
zip_path=dest/'AAMAS2027_working_revision.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files):z.write(p,p.relative_to(ROOT))
 z.writestr('PACKAGE_MANIFEST.json',json.dumps(manifest,indent=2));z.writestr('PACKAGE_README.txt',note)
with tempfile.TemporaryDirectory(prefix='aamas-package-check-') as temp:
 with zipfile.ZipFile(zip_path) as z:z.extractall(temp)
 for name,digest in manifest.items():assert hashlib.sha256((Path(temp)/name).read_bytes()).hexdigest()==digest
 for doc in ['main','supplement']:
  # Force independent compilation instead of trusting bundled PDFs.
  result=subprocess.run(['latexmk','-g','-pdf','-interaction=nonstopmode','-halt-on-error','-outdir=build',doc+'.tex'],cwd=temp,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  (dest/f'package_{doc}_build.log').write_text(result.stdout);assert result.returncode==0,result.stdout[-3000:]
  log=(Path(temp)/f'build/{doc}.log').read_text();assert 'Overfull' not in log and 'undefined references' not in log
report=dict(package=str(zip_path.relative_to(ROOT)),file_count=len(files),sha256=hashlib.sha256(zip_path.read_bytes()).hexdigest(),source_hashes_match=True,isolated_main_and_supplement_build='PASS',scope='Build and source synchronization only; scientific gaps remain in master ledger.')
(dest/'verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

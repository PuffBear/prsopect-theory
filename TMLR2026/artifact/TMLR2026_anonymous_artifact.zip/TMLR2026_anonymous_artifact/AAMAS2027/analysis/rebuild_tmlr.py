#!/usr/bin/env python3
"""Regenerate all quantitative TMLR outputs and compile the manuscript.

Run from any directory inside the unpacked artifact. The script intentionally
uses the checked analysis programs rather than treating copied TeX tables as
authoritative.
"""

from pathlib import Path
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[2]
AAMAS = ROOT / "AAMAS2027"
TMLR = ROOT / "TMLR2026"


def run(*args: str, cwd: Path = ROOT) -> None:
    print("+", " ".join(args), flush=True)
    subprocess.run(args, cwd=cwd, check=True)


def copy(rel: str) -> None:
    src = AAMAS / "generated" / rel
    dst = TMLR / "generated" / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


run(sys.executable, str(AAMAS / "analysis" / "reanalyze.py"))
run(sys.executable, str(AAMAS / "analysis" / "render_results.py"))
run(sys.executable, str(AAMAS / "analysis" / "final_diagnostic_checks.py"))
run(sys.executable, str(AAMAS / "analysis" / "render_confirmation.py"))
run(sys.executable, str(AAMAS / "analysis" / "analyze_equivalent_budget.py"))
run(sys.executable, str(AAMAS / "analysis" / "export_tmlr_macros.py"))

for rel in [
    "numbers.tex",
    "boundary_observed.pdf",
    "decomposition_observed.pdf",
    "supply_cells.tex",
    "lambda_table.tex",
]:
    copy(rel)

for src in sorted((AAMAS / "generated" / "confirmation").iterdir()):
    if src.is_file():
        copy(str(src.relative_to(AAMAS / "generated")))

run(
    "latexmk",
    "-pdf",
    "-interaction=nonstopmode",
    "-halt-on-error",
    "-outdir=build",
    "main.tex",
    cwd=TMLR,
)
print(f"Rebuilt {TMLR / 'build' / 'main.pdf'}")

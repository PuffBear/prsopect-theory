"""Guarded four-arm analysis: no boundary inference from incomplete/pilot data."""
from pathlib import Path
import argparse,json,gzip
import numpy as np,pandas as pd
from boundary import firth
from reanalyze import matrices

def analyze(root,out,grid):
 out=Path(out);out.mkdir(parents=True,exist_ok=True);rows=[]
 for p in Path(root).rglob('protocol.json'):
  c=json.loads(p.read_text());result=p.parent/'evaluation_300000.json'
  if c.get('phase')!='confirmation' or c.get('arm') not in ['A','B','S','N'] or not result.exists():continue
  r=json.loads(result.read_text());rows.append(dict(arm=c['arm'],reference=c['reference'],w=c['w'],seed=c['seed'],y=int(r['summary']['collapsed']),actual=r['actual_agent_transitions'],folder=str(p.parent)))
 d=pd.DataFrame(rows)
 if d.empty:
  (out/'status.json').write_text(json.dumps({'status':'no complete confirmation records; no scalar-control conclusion'}));return
 d.to_csv(out/'confirmation_runs.csv',index=False)
 results=[];contrasts=[]
 for ref,g in d.groupby('reference'):
  expected={(arm,w,seed) for arm in ['A','B','S','N'] for w in grid for seed in range(42,62)};actual=list(zip(g.arm,g.w,g.seed))
  if len(actual)!=len(set(actual)):raise ValueError('duplicate confirmation cell/seed')
  if set(actual)!=expected:
   (out/f'incomplete_reference_{ref}.json').write_text(json.dumps(dict(missing=sorted(expected-set(actual)),unexpected=sorted(set(actual)-expected))));continue
  weights=np.random.default_rng(20260927).multinomial(20,np.full(20,.05),size=2000);fits={}
  for arm,h in g.groupby('arm'):
   w,k,n=matrices(h,list(range(42,62)));point=firth(w,k.sum(0),n.sum(0));boot=firth(w,weights@k,weights@n);z=boot['wcrit'];ok=np.isfinite(z);ci=np.percentile(z[ok],[2.5,97.5]) if ok.any() else [np.nan,np.nan];prop=k.sum(0)/n.sum(0)
   fits[arm]=(point['wcrit'][0],z)
   results.append(dict(reference=ref,arm=arm,wcrit=point['wcrit'][0],ci_low=ci[0],ci_high=ci[1],bracket=bool(prop.min()<=.5<=prop.max()),in_grid=point['in_grid'][0],status=point['status'][0],usable=int(ok.sum())))
  for high,low in [('A','S'),('N','B'),('A','B')]:
   p,z=fits[high];p0,z0=fits[low];delta=z-z0;ok=np.isfinite(delta);ci=np.percentile(delta[ok],[2.5,97.5]) if ok.any() else [np.nan,np.nan]
   contrasts.append(dict(reference=ref,contrast=high+'-'+low,difference=p-p0,ci_low=ci[0],ci_high=ci[1],usable=int(ok.sum())))
 pd.DataFrame(results).to_csv(out/'boundaries.csv',index=False);pd.DataFrame(contrasts).to_csv(out/'contrasts.csv',index=False)
 # Aggregate first and second moments, not squared mean standard deviations.
 metrics=[]
 for r in d.itertuples():
  path=Path(r.folder)/'diagnostics/rollouts.jsonl.gz'
  if not path.exists():continue
  with gzip.open(path,'rt') as f:records=[json.loads(line) for line in f]
  for window,start in [('all',0),('late',150000)]:
   selected=[x for x in records if start<x['actual_transitions']<=r.actual]
   for agent in ['pooled']+[f'node_{i}' for i in range(2,7)]:
    groups=[next(g for g in x['groups'] if g['agent']==agent) for x in selected]
    for metric in ['centered','transformed','advantages_buffer','returns_buffer']:
     vals=[g[metric] if metric.endswith('_buffer') else g['rewards'][metric] for g in groups];n=sum(v['count'] for v in vals)
     if not n:continue
     mean=sum(v['count']*v['mean'] for v in vals)/n;m2=sum(v['count']*v['rms']**2 for v in vals)/n
     metrics.append(dict(arm=r.arm,reference=r.reference,w=r.w,seed=r.seed,window=window,agent=agent,metric=metric,count=n,mean=mean,std=np.sqrt(max(0,m2-mean*mean)),rms=np.sqrt(m2),positive=sum(v['count']*v['positive'] for v in vals)/n,zero=sum(v['count']*v['zero'] for v in vals)/n,negative=sum(v['count']*v['negative'] for v in vals)/n))
 pd.DataFrame(metrics).to_csv(out/'achieved_scale_and_signs.csv',index=False)
 (out/'status.json').write_text(json.dumps(dict(complete_reference_sets=len(results)//4,interpretation='boundary contrasts alone do not establish achieved scale matching; inspect rollout and actual-minibatch diagnostics')))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--out',required=True);p.add_argument('--grid',default='0,.4,.5,.6,.7,.85,1');a=p.parse_args();analyze(a.root,a.out,[float(x) for x in a.grid.split(',')])

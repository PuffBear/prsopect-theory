# Anonymous TMLR reproducibility artifact

This archive supports the results in *Measuring Finite-Budget Coordination-Collapse Crossings in Reward-Mixed Cooperative MARL*.

## Evidence scope

- `executed_source/instrumented_source_v2/` is the immutable, hash-verified source snapshot used for the new longitudinal confirmation, direct scaling control, evaluation-sensitivity analysis, and optimizer diagnostics.
- `AAMAS2027/new_runs/deadline_confirmation_v1/` contains the 150 longitudinal and 240 direct-control trajectories, checkpoint evaluations, protocols, lineage records, and completion markers.
- `AAMAS2027/new_runs/scale_calibration_v1/` and `scale_calibration_refinement_v2/` contain the independent reference-point calibration records.
- `docs/` contains the audited per-run CSV records for the older supply-PPO crossing, transform, and cross-sectional horizon sweeps. The original execution environment for those legacy rows was not preserved, so the archive does not describe it as an immutable executed-source snapshot.
- Exploratory MPE, LBF, MAPPO, action-discretization, and heterogeneous-node results are outside the paper's confirmatory claims and are not required to reproduce its tables.

## Rebuild every reported analysis output and the manuscript

Create a Python environment compatible with `AAMAS2027/analysis/requirements.lock`, ensure `latexmk` is available, and run this once from the archive root:

```bash
python AAMAS2027/analysis/rebuild_tmlr.py
```

This command re-analyses the legacy primary rows, reruns the 390-policy confirmation audit, regenerates every quantitative table and figure used by the manuscript, exports the abstract macros, and compiles the PDF.

The included `tmlr.sty`, `tmlr.bst`, and `fancyhdr.sty` are unmodified copies from the official TMLR template archive retrieved on 2026-10-15.

## Reproduce only the confirmation analysis

Create a Python environment compatible with `AAMAS2027/analysis/requirements.lock`, then from the archive root run:

```bash
python AAMAS2027/analysis/final_diagnostic_checks.py
python AAMAS2027/analysis/render_confirmation.py
```

The first command validates cohort completeness, source hashes, fixed designs, seed schedules, transition counters, evaluation labels, fitted crossings, paired bootstrap contrasts, and the reported diagnostics. The second rebuilds the confirmation tables and figures from the checked exports.

The older primary sweep is re-analysed by `AAMAS2027/analysis/reanalyze.py`. That audit script also reads the archived transfer rows to preserve its original input contract, although the TMLR manuscript makes no claim from those settings. Its primary supply-PPO inputs are the `expN`, `expB_reduced`, `expPPO_lambda_sweep`, `expHighLambda_finegrid`, `expA`, `expA300k`, and `expHorizon_extra` directories in `docs/`.

## Integrity

`MANIFEST.sha256` lists every archived file and its SHA-256 digest. Paths and records contain no author names or machine usernames. The planned optimizer/normalization factorial is excluded because it has not executed and contributes no reported result.
